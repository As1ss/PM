package al.if05.examen1ev1_alb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    String importe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioButton rbEurOrigen = findViewById(R.id.rbEurOrigen);
        RadioButton rbDolOrigen = findViewById(R.id.rbDolOrigen);
        RadioButton rbBTCOrigen = findViewById(R.id.rbBTCOrigen);

        RadioButton rbEurDestino = findViewById(R.id.rbEurDestino);
        RadioButton rbDolDestino = findViewById(R.id.rbDolDestino);
        RadioButton rbBTCDestino = findViewById(R.id.rbBTCDestino);

        TextView tvConvertirButton = findViewById(R.id.tvConvertirButton);
        TextView tvResultado = findViewById(R.id.tvResultado);
        EditText etImporte = findViewById(R.id.etImporte);
        importe = "";







        tvConvertirButton.setOnClickListener(v -> {
            importe = etImporte.getText().toString();
            //Dolares to lo demás
            if (rbDolOrigen.isChecked() && rbBTCDestino.isChecked()) {

                tvResultado.setText(importe+ " dolares son " + importe + " bitcoins");
            }
            if (rbDolOrigen.isChecked() && rbDolDestino.isChecked()) {

                tvResultado.setText(importe + " dolares son " + importe + " dólares");
            }
            if (rbDolOrigen.isChecked() && rbEurDestino.isChecked()) {

                tvResultado.setText(importe + " dolares son " + importe + " euros");
            }
            //Euros to lo demás
            if (rbEurOrigen.isChecked() && rbBTCDestino.isChecked()) {

                tvResultado.setText(importe + " euros son " + importe + " bitcoins");
            }
            if (rbEurOrigen.isChecked() && rbDolDestino.isChecked()) {

                tvResultado.setText(importe + " euros son " + importe + " dólares");
            }
            if (rbEurOrigen.isChecked() && rbEurDestino.isChecked()) {

                tvResultado.setText(importe + " euros son " + importe+ " euros");
            }
            //Btc to lo demás
            if (rbBTCOrigen.isChecked() && rbBTCDestino.isChecked()) {

                tvResultado.setText(importe + " bitcoins son " + importe + " bitcoins");
            }
            if (rbBTCOrigen.isChecked() && rbDolDestino.isChecked()) {

                tvResultado.setText(importe + " bitcoins son " + importe + " dólares");
            }
            if (rbBTCOrigen.isChecked() && rbEurDestino.isChecked()) {

                tvResultado.setText(importe + " bitcoins son " + importe + " euros");
            }


        });
        }



    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.getString("importe");
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        savedInstanceState.putString("importe", importe);

    }
}