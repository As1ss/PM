package if05.tresenraya;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class GameOverActivity extends AppCompatActivity {

    String userName;
    boolean winGame;
    boolean loseGame;
    boolean tablas;
    TextView tvTest;
    ImageView ivScreenshot;
    MediaPlayer youWinSound;
    MediaPlayer youLoseSound;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);
        ivScreenshot = findViewById(R.id.ivScreenshot);
        Button btnContinue = findViewById(R.id.btnContinue);

        loadComponents();
        showWinner();
        showAnimationWinner();


        btnContinue.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        });



    }

    private void showAnimationWinner() {
        // Crea un ValueAnimator para cambiar la opacidad (alfa) del TextView
        final ValueAnimator alphaAnimator = ValueAnimator.ofFloat(1f, 0.3f); // Valores de opacidad de 1 a 0.3
        alphaAnimator.setDuration(1000); // Duración de la animación en milisegundos
        alphaAnimator.setRepeatCount(ValueAnimator.INFINITE); // Repite la animación infinitamente
        alphaAnimator.setRepeatMode(ValueAnimator.REVERSE); // Invierte la animación al final para que parpadee

        alphaAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animator) {
                float alpha = (float) animator.getAnimatedValue();
                tvTest.setAlpha(alpha);
            }
        });

        // Inicia la animación
        alphaAnimator.start();
    }

    private void loadComponents() {
        String screenshotPath = getIntent().getStringExtra("screenshotPath");
        if (screenshotPath != null && !screenshotPath.isEmpty()) {
            // Cargar la captura de pantalla en el ImageView
            Bitmap screenshotBitmap = BitmapFactory.decodeFile(screenshotPath);
            ivScreenshot.setImageBitmap(screenshotBitmap);
        } else {
            // No se proporcionó una captura de pantalla, puedes ocultar o cambiar el ImageView
            ivScreenshot.setVisibility(View.GONE);
        }
        tvTest = findViewById(R.id.tvTest);
        userName = getIntent().getExtras().get("userName").toString();
        winGame = getIntent().getBooleanExtra("winGame",false);
        loseGame= getIntent().getBooleanExtra("loseGame",false);
        tablas = getIntent().getBooleanExtra("tablas",false);
        youWinSound = MediaPlayer.create(this,R.raw.youwin);

        youLoseSound = MediaPlayer.create(this,R.raw.youlose);
        youLoseSound.setVolume(2f,2f);
    }

    private void showWinner() {
        if (winGame){
            tvTest.setTextColor(Color.GREEN);
            tvTest.setText(getText(R.string.mensajeGanador)+" "+userName);

            youWinSound.start();


        }
        else if (loseGame){
            tvTest.setTextColor(Color.GREEN);
            tvTest.setText(getText(R.string.mensajeGanador)+" "+userName);
            youLoseSound.start();
        }
        else if (tablas){
            tvTest.setTextColor(Color.YELLOW);
            tvTest.setText(userName+" "+getText(R.string.empateTexto));
        }
    }
}

