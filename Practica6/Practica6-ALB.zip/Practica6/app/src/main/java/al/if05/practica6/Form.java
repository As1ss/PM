package al.if05.practica6;

public interface Form {

    public int setMaxScore(boolean mode);
    public int setCorrectAnswer(boolean mode);
    public void initFragment();
}
